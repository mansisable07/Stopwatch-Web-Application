# Stopwatch-Web-Application
built a stopwatch web application by using HTML,CSS and Javascript
